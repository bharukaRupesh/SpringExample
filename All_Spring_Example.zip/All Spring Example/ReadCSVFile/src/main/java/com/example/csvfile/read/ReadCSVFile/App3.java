package com.example.csvfile.read.ReadCSVFile;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/*
 * Reading a CSV file with Header Auto-detection
 * 
 * */
public class App3 {
	private static final String CSV_FILE_PATH = "/home/agsuser/Desktop/test2.csv";
	
	public static void main(String[] args) throws IOException {
		try(Reader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH));
		CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT
											.withFirstRecordAsHeader()
											.withIgnoreHeaderCase()
											.withTrim());){
			
			for(CSVRecord record : parser){
				String name = record.get("Name");
				String email = record.get("Email");
				String phone = record.get("Phone");
				String country = record.get("Country");
				
				System.out.println("Record No - " +record.getRecordNumber());
				System.out.println("Name : " +name);
				System.out.println("Email : " +email);
				System.out.println("Phone : " +phone);
				System.out.println("Country : " +country);
				System.out.println("--------------------------------------");
			}
		}
		
		
	}

}
