package com.agile.app.Dao;

import com.agile.app.Model.Employee;

public interface EmployeeDao {
	public void addEmployeeRecord(Employee employee);
}
