package com.agile.app.DaoImpl;

import com.agile.app.Dao.EmployeeDao;
import com.agile.app.Model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	public void addEmployeeRecord(Employee employee) {
				
	}

}
