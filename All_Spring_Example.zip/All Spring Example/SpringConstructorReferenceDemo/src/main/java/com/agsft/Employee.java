package com.agsft;

public class Employee {
	
	private String empName;
	
	public Employee(String empName){
		this.empName = empName;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
		
}
