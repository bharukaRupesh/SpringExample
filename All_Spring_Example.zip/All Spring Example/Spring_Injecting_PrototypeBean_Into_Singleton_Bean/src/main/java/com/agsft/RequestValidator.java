package com.agsft;

public class RequestValidator {
	
	public RequestValidator(){
		System.out.println("Inside constructor of Request Validator");
	}
	
	public void validateRequest(String requestId){
		System.out.println("Validate Request : " +requestId);
	}
	
}
