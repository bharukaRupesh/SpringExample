package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.velocity.VelocityEngineUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailController {

    @Autowired
    private JavaMailSender sender;

    @Autowired
    private VelocityEngine velocityEngine;

    @RequestMapping("/simpleemail")
    public String home() {
        try {
            sendEmail();
            return "Email has been sent successfully!";
        } catch (Exception ex) {
            return "Error in sending email: " + ex;
        }
    }

    private void sendEmail() throws Exception {
        MimeMessage message = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);

        Map<String, Object> map = new HashMap<>();
        map.put("user", "Pramod");
//        String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "resetPass.html", map);
        String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "welcome.vm", map);

        helper.setTo("pkitekar@agsft.com");
        helper.setText(text, true); // set to html
        helper.setSubject("Hi");

        sender.send(message);
    }
    
}
