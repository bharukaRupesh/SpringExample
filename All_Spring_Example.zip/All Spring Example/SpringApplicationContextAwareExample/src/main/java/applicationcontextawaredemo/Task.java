package applicationcontextawaredemo;

public class Task {
	public void doSomeTask(){
		System.out.println("Do some task");
	}
}	
