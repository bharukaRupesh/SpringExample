package com.agile.Dao;

import com.agile.model.Student;

public interface StudentDAO {
	public void addStudentRecord(Student student);
}
