package com.agile.Service;

import com.agile.model.Student;

public interface StudentService {
	public void addStudentRecord(Student student);
}