package com.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.HandlerExceptionResolver;

@SpringBootApplication
@Controller
@EnableAutoConfiguration
public class SentryDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SentryDemoApplication.class, args);
	}
	
    /*
    Register a HandlerExceptionResolver that sends all exceptions to Sentry
    and then defers all handling to the other HandlerExceptionResolvers.
    You should only register this is you are not using a logging integration,
    otherwise you may double report exceptions.
     */
    @Bean
    public HandlerExceptionResolver sentryExceptionResolver() {
        return new io.sentry.spring.SentryExceptionResolver();
    }
    
    /*
	    Register a ServletContextInitializer that installs the SentryServletRequestListener
	    so that Sentry events contain HTTP request information.
	    This should only be necessary in Spring Boot applications. "Classic" Spring
	    should automatically load the `io.sentry.servlet.SentryServletContainerInitializer`.
     */
    @Bean
    public ServletContextInitializer sentryServletContextInitializer() {
        return new io.sentry.spring.SentryServletContextInitializer();
    }
    
    @RequestMapping("/divide/number")
    @ResponseBody
    public String home() {
        int x = 1 / 0;

        return "Hello World!";
    }
    
    @RequestMapping("/test/method")
    @ResponseBody
    public void testMethod() {
    	int[] array = new int[5];
    	int value = array[8];
    }
    
}
