package com.test;

/*import org.junit.Test;
import org.junit.runner.RunWith;*/
import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


//@RunWith(SpringRunner.class)
@SpringBootTest
public class RestAssured1ApplicationTests {

	@Test
	public void contextLoads() {
	}

	@Test
	public void test_event_under_org(){
		get("http://192.168.50.54:8080/eventsUnderOrg?orgName=SEASONS").then().body("response_code", equalTo(200)).log().all();
	}
	
	@Test
	public void test_login(){

		//Passed
		/*given().contentType(ContentType.JSON).body("{\"email\": \"ruth.sysadmn@gmail.com\", \"password\": \"Password123#\"}").    
        when().post("http://192.168.50.54:8080/login").then().assertThat().statusCode(200);*/
	
		
		//Passed
		/*given().contentType(ContentType.JSON).body("{\"email\": \"ruth.sysadmn@gmail.com\", \"password\": \"Password123#\"}").    
        when().post("http://192.168.50.54:8080/login").then().assertThat().statusCode(200).body("response_body.userProfile.userId", equalTo("5aaa5c896d3fed1b85b06b71"));*/
		
		
/*		//Step by step working
  		
  		RequestSpecification reqSpecification = RestAssured.given();
		RequestSpecification contentTypeJson = reqSpecification.contentType(ContentType.JSON);
		RequestSpecification bodyOfJson = contentTypeJson.body("{\"email\": \"ruth.sysadmn@gmail.com\", \"password\": \"Password123#\"}");
		Response response = bodyOfJson.when().post("http://192.168.50.54:8080/login");
		
		ValidatableResponse validateResponse = response.then();
*/
		
		given().contentType(ContentType.JSON).body("{\"email\": \"ruth.sysadmn@gmail.com\", \"password\": \"Password123#\"}").    
        when().post("http://192.168.50.54:8080/login").then().assertThat().statusCode(200).body("response_body.userProfile.userId", equalTo("5aaa5c896d3fed1b85b06b71"));
	}
	
}
