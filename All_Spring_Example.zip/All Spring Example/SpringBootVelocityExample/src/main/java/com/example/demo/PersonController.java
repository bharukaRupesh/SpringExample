package com.example.demo;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PersonController {
	private static final Logger logger = LoggerFactory.getLogger(PersonController.class);
	
	@Autowired
	private JavaMailSender sender;
	
	
	@RequestMapping("/simpleemail")
    public String home() {
        try {
//            sendEmail(); // to send simple text message
//        	sendAttachment(); // to send attached file
        	sendEmailWithInlineResource();
        	logger.info("Email has been sent successfully!");
            return "Email has been sent successfully!";
            
        }catch(Exception ex) {
            logger.error("Error! Email can not be sent:" +ex);
        	return "Error in sending email: "+ex;
        }
    }

	/*private void sendEmail() throws Exception{
        MimeMessage message = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);
        
        helper.setTo("pkitekar@agsft.com");
        helper.setText("How are you?");
        helper.setSubject("Hi");
        
        sender.send(message);
    }
	

    private void sendAttachment() throws Exception{
        MimeMessage message = sender.createMimeMessage();
        
        // Enable the multipart flag!
        MimeMessageHelper helper = new MimeMessageHelper(message,true);
        
        helper.setTo("pkitekar@agsft.com");
        helper.setText("How are you?");
        helper.setSubject("Hi");
        
        ClassPathResource file = new ClassPathResource("cartoon.png");
        helper.addAttachment("cartoon.png", file);
        
        sender.send(message);
    }*/
    
    private void sendEmailWithInlineResource() throws Exception {
        MimeMessage message = sender.createMimeMessage();

        // Enable the multipart flag!
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo("rupeshb@agsft.com");
        helper.setText("<html><body>Here is a cartoon picture! <img src='cid:id101'/><body></html>", true);
        helper.setSubject("Hi");

        ClassPathResource file = new ClassPathResource("cartoon.png");
        helper.addInline("id101", file);

        sender.send(message);
    }
	
}
