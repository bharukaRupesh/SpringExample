package com.Agilesoft;

import java.util.List;
import java.util.Map;

public class SpringCollectionExample {
	private List<String> listOfNames;
	private Map<String, String> map;
	
	public List<String> getListOfNames() {
		return listOfNames;
	}
	public void setListOfNames(List<String> listOfNames) {
		this.listOfNames = listOfNames;
	}

	public Map<String, String> getMap() {
		return map;
	}
	public void setMap(Map<String, String> map) {
		this.map = map;
	}	
	
}
