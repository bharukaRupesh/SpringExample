package com.agsft;


public class Employee {
	
	private String employeeName;

	
	public Employee(String empName){
		this.employeeName = empName;
	} 
	
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
}
