package com.agsft.springxmldemo;

public class HelloWorld {
	
	private String greetings;

	
	public void setGreetings(String greetings) {
		this.greetings = greetings;
	}
	
	public void displayGreetings(){
		System.out.println("Greetings : " +greetings);
	}	
	
}
