package com.agsft;

public class PrintableFactory {
	// an instance factory method
	public Printable getInstance(){
		return new A();
	}
}
