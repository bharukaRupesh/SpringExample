package com.agsft;

public interface Printable {
	public void print();
}
