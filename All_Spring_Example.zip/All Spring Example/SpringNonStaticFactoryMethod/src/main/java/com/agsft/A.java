package com.agsft;

public class A implements Printable{

	public void print() {
		System.out.println("Inside print of A");
	}
	
}
