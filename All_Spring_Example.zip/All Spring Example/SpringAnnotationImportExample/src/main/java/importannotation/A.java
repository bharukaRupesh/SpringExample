package importannotation;

public class A {
	private String aMessage;

	public String getaMessage() {
		return aMessage;
	}

	public void setaMessage(String aMessage) {
		this.aMessage = aMessage;
	}

}
