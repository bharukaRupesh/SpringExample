package importannotation;

public class B {
	private String bMessage;

	public String getbMessage() {
		return bMessage;
	}

	public void setbMessage(String bMessage) {
		this.bMessage = bMessage;
	}

}
