package com.agsft;

public class Company {
	private String companyName;
	private String locationOfCompany;

	
	public String getCompanyName() {
		return companyName;
	}
	
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getLocationOfCompany() {
		return locationOfCompany;
	}
	
	public void setLocationOfCompany(String locationOfCompany) {
		this.locationOfCompany = locationOfCompany;
	}

}
