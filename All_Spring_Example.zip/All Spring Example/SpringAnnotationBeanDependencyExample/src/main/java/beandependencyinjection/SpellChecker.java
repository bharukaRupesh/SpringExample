package beandependencyinjection;

public class SpellChecker {
	
	// default constructor
	public SpellChecker() {
		System.out.println("Inside SpellChecker constructor.");
	}

	public void checkSpelling() {
		System.out.println("Inside checkSpelling of SpellChecker.");
	}
}
