package com.agsft;

public class Employee {

	public Employee() {
		System.out.println("Employee constructor");
	}

	public void msg(String value) {
		System.out.println("hello " + value);
	}
	
}
