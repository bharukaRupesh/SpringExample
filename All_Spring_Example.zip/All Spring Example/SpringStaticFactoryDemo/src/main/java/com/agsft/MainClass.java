package com.agsft;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	
	private static AbstractApplicationContext context;

	public static void main(String[] args) {
	
		context = new ClassPathXmlApplicationContext("EmployeeConfig.xml");
		
		Employee eRef = (Employee) context.getBean("emp");
		eRef.msg(" Everyone");
		//System.out.println("Employee Name : " +eRef.getEmployeeName());
	}
}
