package com.agsft;

public class EmployeeInstance {

	private static final Employee employee = new Employee();

	public static Employee getEmployeeInstance() {
		System.out.println("factory method ");
		return employee;
	}
	
}
