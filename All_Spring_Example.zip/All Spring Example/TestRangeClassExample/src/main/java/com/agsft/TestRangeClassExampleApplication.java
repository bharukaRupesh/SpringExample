package com.agsft;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.Range;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class TestRangeClassExampleApplication {

	public static void main(String[] args) {
		
		List<Range>listOfExistingCustomerRange = new ArrayList<>();
		
		//list of existing customer
		Range<Integer>rangeOfInt1 = Range.between((int)5, (int)10); //auto-boxing if you don't typecast
		Range<Integer>rangeOfInt2 = Range.between((int)11, (int)21); //auto-boxing if you don't typecast
		
		listOfExistingCustomerRange.add(rangeOfInt1);
		listOfExistingCustomerRange.add(rangeOfInt2);
		
		
		//new customer
		Range<Integer>rangeOfNewCustomer = Range.between((int)21,(int)25);
		
		for(Range range : listOfExistingCustomerRange){
			if(rangeOfNewCustomer.isAfterRange(range) || rangeOfNewCustomer.isBeforeRange(range)){
				System.out.println("range : true :  "+range.toString());
			}else{
				System.out.println("range : false :  "+range.toString());
			}
		}
		
		
		/*for(Range range : listOfExistingCustomerRange){
			if((range.isAfterRange(rangeOfNewCustomer)||range.isBeforeRange(rangeOfNewCustomer))){
				System.out.println("range : true :  "+range.toString());
			}else{
				System.out.println("range : false :  "+range.toString());
			}
		}*/
		
	} 
}
